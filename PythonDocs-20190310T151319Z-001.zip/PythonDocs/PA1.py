def main():
    print("Hello World!")
    name = input("What is your name? ")
    print("Hello " + name + "!")
    print("This program is now complete and will Exit now. Have a great day!")


main()